# # app/auth_utils.py

# SECRET_KEY = "your_secret_key_here"  # Replace with a real secret in production!
# ALGORITHM = "HS256"
# ACCESS_TOKEN_EXPIRE_MINUTES = 30
