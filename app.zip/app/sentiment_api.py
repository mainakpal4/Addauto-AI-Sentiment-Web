import httpx
import os
from dotenv import load_dotenv
from app.schemas import EmotionResponse

# Load environment variables
load_dotenv()
MODEL_API_URL = os.getenv("MODEL_API_URL")

async def analyze_sentiment(text: str) -> EmotionResponse:
    async with httpx.AsyncClient() as client:
        response = await client.post(MODEL_API_URL, json={"text": text})
        response.raise_for_status()
        data = response.json()

        return EmotionResponse(
            timestamp=data["timestamp"],
            text=data["text"],
            language=data["language"],
            emotion=data["emotion"],
            confidence=data["confidence"],
            emoji=data["emoji"],
            top_emotions=data["top_emotions"]
        )
