import traceback
from fastapi import APIRouter, HTTPException
from app.schemas import TextInput, EmotionResponse
from app.sentiment_api import analyze_sentiment

router = APIRouter()

@router.post("/analyze")
@router.post("/analyze/")
async def analyze_text(input_text: TextInput):
    try:
        return await analyze_sentiment(input_text.text)
    except Exception as e:
        traceback.print_exc()  # 👈 This logs the actual error to your terminal
        raise HTTPException(status_code=500, detail=str(e))
