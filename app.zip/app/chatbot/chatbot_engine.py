import torch
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
from app.chatbot.prompt_generator import build_prompt
import os
from dotenv import load_dotenv

load_dotenv()

MODEL_NAME = os.getenv("MODEL_NAME", "google/flan-t5-base")

# ✅ Load model and tokenizer only once at module level
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME).to("cpu")

def generate_emotion_aware_reply(user_input: str) -> str:
    prompt = build_prompt(user_input)
    inputs = tokenizer(prompt, return_tensors="pt").to("cpu")

    with torch.no_grad():
        outputs = model.generate(**inputs, max_new_tokens=100)

    reply = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return reply
