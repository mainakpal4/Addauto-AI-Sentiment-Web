from app.chatbot.templates import system_template, user_template

def build_prompt(user_input: str) -> str:
    user_part = user_template.format(user_input=user_input)
    return f"{system_template}\n{user_part}"
