from pydantic import BaseModel
from typing import List

class TextInput(BaseModel):
    text: str

class EmotionItem(BaseModel):
    emotion: str
    confidence: float
    emoji: str

class EmotionResponse(BaseModel):
    timestamp: str
    text: str
    language: str
    emotion: str
    confidence: float
    emoji: str
    top_emotions: List[EmotionItem]
