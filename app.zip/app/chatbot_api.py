from fastapi import APIRouter
from pydantic import BaseModel
from app.chatbot.chatbot_engine import generate_emotion_aware_reply

router = APIRouter()

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    reply: str

@router.post("/chatbot/reply", response_model=ChatResponse)
def get_chat_reply(request: ChatRequest):
    try:
        response = generate_emotion_aware_reply(request.message)
        return {"reply": response}
    except Exception as e:
        return {"reply": f"Error: {str(e)}"}
